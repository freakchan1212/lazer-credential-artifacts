#!/usr/bin/env bash
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
start_log smoke
[[ -x "$ROOT/.venv/bin/python3" ]] || { echo 'Run bash 01_build.sh first'; exit 1; }
source "$ROOT/.venv/bin/activate"
python3 "$ROOT/verify_baseline.py"
cd "$ROOT/lazer/python/anon_cred"
echo '=== Official unmodified demo ==='
python3 -u anon_cred.py
echo '=== Three fresh normal-path sessions ==='
python3 -u "$ROOT/bench_normal_path.py" --mode smoke --sessions 3 --warmup 0
echo "SMOKE_PASSED"
