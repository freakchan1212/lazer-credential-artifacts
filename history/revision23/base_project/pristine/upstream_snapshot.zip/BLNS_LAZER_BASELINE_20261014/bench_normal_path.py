#!/usr/bin/env python3
"""Measurement wrapper only. Calls the untouched upstream protocol classes."""
import argparse, csv, hashlib, json, os, platform, secrets, statistics, sys, time, uuid
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DEMO=ROOT/'lazer/python/anon_cred'
os.chdir(DEMO)
sys.path.insert(0,str(DEMO))
sys.path.insert(1,str(DEMO.parent))
import anon_cred as ac

def timed(fn):
    start=time.perf_counter_ns()
    value=fn()
    return value,(time.perf_counter_ns()-start)/1e6

def trial(index, pk, sk):
    msg=secrets.token_bytes(64)
    public=[0,4,5]
    hidden=[i for i in range(8) if i not in public]
    user,ui=timed(lambda: ac.user_t(pk))
    issuer,ii=timed(lambda: ac.signer_t(pk,sk))
    verifier,vi=timed(lambda: ac.verifier_t(pk))
    masked,mask_ms=timed(lambda: user.maskmsg(msg))
    blind,issue_ms=timed(lambda: issuer.sign(masked))
    proof,prove_ms=timed(lambda: user.sign(blind,public))
    pub_msg=ac.zero_out_bytes(msg,hidden,ac.RING.deg//8)
    _,verify_ms=timed(lambda: verifier.verify(pub_msg,public,proof))
    return dict(session=index,status='HONEST_ACCEPTED',user_init_ms=ui,
        issuer_init_ms=ii,verifier_init_ms=vi,mask_and_p1_prove_ms=mask_ms,
        p1_verify_and_issue_ms=issue_ms,p2_prove_ms=prove_ms,p2_verify_ms=verify_ms,
        issue_flow_ms=mask_ms+issue_ms,show_flow_ms=prove_ms+verify_ms,
        masked_request_bytes=len(masked),blind_credential_bytes=len(blind),
        presentation_proof_bytes=len(proof))

def stats(values):
    xs=sorted(values)
    return dict(mean=statistics.mean(xs),median=statistics.median(xs),
        min=xs[0],max=xs[-1],p95_nearest_rank=xs[max(0,__import__('math').ceil(.95*len(xs))-1)])

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode',choices=['smoke','pilot'],default='smoke')
    ap.add_argument('--sessions',type=int,default=3)
    ap.add_argument('--warmup',type=int,default=0)
    args=ap.parse_args()
    if args.sessions<1 or args.sessions>1000 or args.warmup<0 or args.warmup>10:
        ap.error('sessions must be 1..1000; warmup must be 0..10')
    out=ROOT/'results'/f'{args.mode}_{datetime.now().strftime("%Y%m%d_%H%M%S")}_{uuid.uuid4().hex[:6]}'
    out.mkdir(parents=True)
    summary=dict(mode=args.mode,requested_sessions=args.sessions,warmup=args.warmup,
        created_at_utc=datetime.now(timezone.utc).isoformat(),
        upstream_commit='10eafeca4cd53ff4fc54193dce904dbd0026fefd',
        disclosure_blocks=[0,4,5],hidden_blocks=[1,2,3,6,7],
        block_bits=64,message_bits=512,ring_degree=64,modulus=12289,
        p1_relation_shape=[8,24],p2_relation_shape=[8,48],
        semantics='Each recorded trial creates fresh user/issuer/verifier proof states, masks a fresh 64-byte binary message, issues one credential and shows it once. One issuer keypair is shared across trials. No authentication nonce binding has been added.',
        python=sys.version,python_executable=sys.executable,platform=platform.platform(),
        accepted=0,status='RUNNING')
    (out/'environment.txt').write_text(platform.platform()+'\n'+sys.version+'\n'+Path('/proc/cpuinfo').read_text())
    rows=[]
    fields=['session','status','user_init_ms','issuer_init_ms','verifier_init_ms',
        'mask_and_p1_prove_ms','p1_verify_and_issue_ms','p2_prove_ms','p2_verify_ms',
        'issue_flow_ms','show_flow_ms','masked_request_bytes','blind_credential_bytes',
        'presentation_proof_bytes']
    try:
        keys,summary['keygen_ms']=timed(ac.falcon_keygen)
        sk,pk,_=keys
        for i in range(args.warmup):
            trial(-i-1,pk,sk)
        with (out/'sessions.csv').open('w',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=fields)
            writer.writeheader()
            for i in range(args.sessions):
                row=trial(i+1,pk,sk)
                writer.writerow(row); f.flush(); rows.append(row)
                summary['accepted']+=1
                print(f"[{i+1}/{args.sessions}] HONEST_ACCEPTED | P2={row['presentation_proof_bytes']} B | prove={row['p2_prove_ms']:.3f} ms | verify={row['p2_verify_ms']:.3f} ms",flush=True)
        summary['metrics']={k:stats([row[k] for row in rows]) for k in fields if k not in ['session','status']}
        summary['status']='NORMAL_PATH_PASSED'
    except Exception as exc:
        summary['status']='FAILED'
        summary['error_type']=type(exc).__name__
        summary['error_message']=str(exc)
        raise
    finally:
        (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
        print('RESULT_DIRECTORY:',out,flush=True)
    print(f"NORMAL_PATH_PASSED: {summary['accepted']}/{args.sessions}",flush=True)

if __name__=='__main__': main()
