#!/usr/bin/env bash
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
start_log build
choose_python
export CC="${CC:-gcc}" CXX="${CXX:-g++}"
JOBS="${JOBS:-2}"
[[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || { echo 'JOBS must be a positive integer'; exit 1; }
bash "$ROOT/00_check_env.sh"
"$PY" "$ROOT/verify_baseline.py"
if [[ ! -x "$ROOT/.venv/bin/python3" ]]; then
  "$PY" -m venv "$ROOT/.venv"
fi
source "$ROOT/.venv/bin/activate"
python3 -m pip install 'cffi>=1.15,<3' 'setuptools>=68,<83' wheel
python3 -m pip freeze > "$ROOT/logs/python_packages.txt"
# Build the exact cpu_features revision requested by upstream HEXL locally.
# This avoids HEXL's configure-time GitHub clone and leaves LaZer sources intact.
cmake -S "$ROOT/vendor/cpu_features" -B "$ROOT/.build/cpu_features" \
  -DCMAKE_INSTALL_PREFIX="$ROOT/.deps" -DCMAKE_INSTALL_LIBDIR=lib -DBUILD_PIC=ON \
  -DBUILD_TESTING=OFF -DBUILD_SHARED_LIBS=OFF
cmake --build "$ROOT/.build/cpu_features" --parallel "$JOBS"
cmake --install "$ROOT/.build/cpu_features"
export CMAKE_PREFIX_PATH="$ROOT/.deps${CMAKE_PREFIX_PATH:+:$CMAKE_PREFIX_PATH}"
if [[ ! -d "$ROOT/lazer/third_party/hexl-development" ]]; then
  unzip -q "$ROOT/lazer/third_party/hexl-development.zip" -d "$ROOT/lazer/third_party"
fi
cmake -S "$ROOT/lazer/third_party/hexl-development" \
  -B "$ROOT/lazer/third_party/hexl-development/build" -DHEXL_BENCHMARK=OFF -DHEXL_TESTING=OFF
cmake --build "$ROOT/lazer/third_party/hexl-development/build" --parallel "$JOBS"
# Only the LaZer linear-proof backend is needed by anon_cred.
# The official CFFI builder supports this without the optional LaBRADOR libraries.
make -C "$ROOT/lazer" -j"$JOBS" lib
# Upstream leaves HEXL symbols to the Python extension. Python distributions
# using --exclude-libs,ALL hide them, causing an import-time undefined symbol.
# Link identical upstream objects directly with their native dependencies.
# No protocol, source, optimization flags or proof parameters are changed.
HEXL_ARCHIVE="$ROOT/lazer/third_party/hexl-development/build/hexl/lib/libhexl.a"
if [[ ! -f "$HEXL_ARCHIVE" ]]; then
  HEXL_ARCHIVE="$ROOT/lazer/third_party/hexl-development/build/hexl/lib64/libhexl.a"
fi
"$CXX" -shared -Wl,-z,defs -o "$ROOT/lazer/liblazer.so" \
  "$ROOT/lazer/src/lazer_shared.o" "$ROOT/lazer/src/hexl_shared.o" \
  "$ROOT/lazer/third_party/Falcon-impl-20211101/"*_shared.o \
  "$HEXL_ARCHIVE" "$ROOT/.deps/lib/libcpu_features.a" -lmpfr -lgmp -lm
make -C "$ROOT/lazer/python"
# Compile the shipped, hash-checked parameter header directly: no Sage required.
cd "$ROOT/lazer/python/anon_cred"
python3 ../params_cffi_build.py anon_cred_params.h ../..
python3 -c 'import anon_cred; print("ANON_CRED_IMPORT_OK")'
echo "BUILD_PASSED"
