#include "lazer.h"

//XXX
