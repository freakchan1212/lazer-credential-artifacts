Reference
=========

.. automodule:: lazer
   :members: