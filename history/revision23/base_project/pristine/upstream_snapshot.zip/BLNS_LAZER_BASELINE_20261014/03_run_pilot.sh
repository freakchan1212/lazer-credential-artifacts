#!/usr/bin/env bash
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
start_log pilot
[[ -x "$ROOT/.venv/bin/python3" ]] || { echo 'Run bash 01_build.sh first'; exit 1; }
source "$ROOT/.venv/bin/activate"
python3 "$ROOT/verify_baseline.py"
python3 -u "$ROOT/bench_normal_path.py" --mode pilot --sessions "${1:-30}" --warmup 1
echo "PILOT_PASSED"
