# BLNS / LaZer 官方匿名凭证正常路径基线

本包先复现官方代码，不改变协议、维度、模数、范数界或证明参数。
LaZer 固定到官方 README 指定的 CCS 2024 复现版本：
`10eafeca4cd53ff4fc54193dce904dbd0026fefd`。

## 1. 这次验证的内容

流程：用户隐藏属性并生成 P1 → 发行者验证 P1 并生成盲化凭证 → 用户生成 P2 → 验证者验证 P2。

- `02_run_smoke.sh`：先运行未经改动的官方示例，再运行 3 次新鲜输入的正常流程。
- `03_run_pilot.sh 30`：先进行 1 次不计入结果的预热，再记录 30 次正常流程。
- 每次记录都使用新消息、新掩蔽随机性和新证明状态；整个测量共享一个发行者密钥对。
- 本包是匿名凭证密码学流程基线。官方示例尚未加入验证者新鲜挑战/会话绑定，不能把它当成完整的防重放网络认证服务。
- Honest accepted 是正确性结果，不是匿名性或不可伪造性的实验“证明”。

## 2. Ubuntu 运行命令

解压到下载目录（如果文件下载在别处，请替换第一条 cd）：

```bash
cd ~/下载
unzip BLNS_LAZER_BASELINE_20261014.zip
cd BLNS_LAZER_BASELINE_20261014
```

依赖已装好时，直接执行：

```bash
bash 00_check_env.sh
bash 01_build.sh
bash 02_run_smoke.sh
```

看到 `SMOKE_PASSED` 后再执行：

```bash
bash 03_run_pilot.sh 30
bash 04_collect_results.sh
```

最后生成 `normal_path_results_时间.zip`，将其回传用于分析。不要先跑 full。

首次缺依赖时，在 Ubuntu 本机安装：

```bash
sudo apt update
sudo apt install -y build-essential cmake git unzip libgmp-dev libmpfr-dev python3-dev python3-venv
```

本包自动建立独立 `.venv`，默认使用 `/usr/bin/python3`，不依赖当前终端的 Conda base。
首次安装 Python 的 cffi 需要访问 pip 源。HEXL 所需的 cpu_features 固定版本已随包提供，构建时无需再次从 GitHub 克隆它。
构建封装将同一批上游目标文件与 HEXL/GMP/MPFR 显式链接，处理部分 Python 发行版隐藏静态库符号造成的导入错误；该处理不改变源码或密码学算法。

官方要求 Linux x86_64、AVX512/AES，并推荐 GCC ≥13.2、CMake ≥3.26、Python ≥3.10。
脚本还检查这个固定优化构建需要的 AVX2/FMA。Ubuntu 22.04 自带工具链可能低于推荐版本；脚本会报告版本并尝试编译，实际是否可用以构建结果为准。如果失败，回传 `logs` 中的检查和构建日志，不需要先盲目升级系统。

默认只使用 2 个编译任务，以免笔记本内存不足。可以显式设置：

```bash
JOBS=4 bash 01_build.sh
```

这个原版复现使用已生成的 `anon_cred_params.h`，无需安装 SageMath。修改参数规格后则必须重新生成相匹配的 header；不能沿用旧 header。本包的原版构建/运行脚本会做源码哈希检查，防止将修改后的实现误当成原版基线。

## 3. 成功输出

官方 demo 应打印多次 `[OK]`，并给出凭证字节数、Issue time 和 Show time。
计时脚本逐条打印：

```text
[1/3] HONEST_ACCEPTED | P2=... B | prove=... ms | verify=... ms
NORMAL_PATH_PASSED: 3/3
SMOKE_PASSED
```

Pilot 最后应为 `NORMAL_PATH_PASSED: 30/30` 和 `PILOT_PASSED`。
任何异常会使脚本返回非零；不会把失败记录成接受。

## 4. 结果怎么看

每次测量写入独立的 `results/smoke_时间_随机后缀` 或 `results/pilot_时间_随机后缀`：

- `sessions.csv`：逐次数据。
- `summary.json`：接受数量、均值、中位数、最小/最大和 nearest-rank P95。
- `environment.txt`：Python、系统和 CPU 信息，不含密钥或隐藏属性。
- `logs/`：构建、官方 demo 和运行日志。

| 指标 | 含义 |
|---|---|
| keygen_ms | 发行者密钥生成，仅测一次，不加入每次出示 |
| user_init_ms / issuer_init_ms / verifier_init_ms | 各角色证明状态初始化，单独记录 |
| mask_and_p1_prove_ms | 用户掩蔽属性并生成 P1 |
| p1_verify_and_issue_ms | 发行者验证 P1 并签发盲化凭证 |
| p2_prove_ms | 用户生成匿名出示证明，正常认证路径的重点 |
| p2_verify_ms | 验证者检查匿名出示证明 |
| issue_flow_ms | 掩蔽/P1 + 签发，用于报告凭证获取成本 |
| show_flow_ms | P2 生成 + P2 验证，不包含角色初始化、网络、会话绑定或消息处理 |
| presentation_proof_bytes | 仅 P2 证明长度，不是含全部元数据的网络报文长度 |

30 次 pilot 用于检查流程和发现瓶颈；不足以支持稳定尾延迟或大样本性能结论。

## 5. 当前官方结构与后续检查入口

| 文件 | 内容 |
|---|---|
| lazer/python/anon_cred/anon_cred.py | user_t、signer_t、verifier_t 及官方 main |
| lazer/python/anon_cred/anon_cred_p1_params.py | P1：degree=64，modulus=12289，关系 8×24 |
| lazer/python/anon_cred/anon_cred_p2_params.py | P2：degree=64，modulus=12289，关系 8×48 |
| lazer/python/anon_cred/anon_cred_params.h | 与上面规格配套的已生成参数 |
| lazer/docs/source/anoncred.rst | 官方匿名凭证说明 |
| bench_normal_path.py | 本包新增的外部计时封装，不修改官方类 |

官方示例消息为 64 字节，分成 8 个 64-bit 多项式块；披露块 `[0,4,5]`，隐藏块 `[1,2,3,6,7]`。这些是编码块，不能直接当成已经定义好语义的“姓名/年龄”等业务属性。

代码确实将公开块对应的消息多项式和矩阵列置零，但 P2 仍保留 48 列的固定关系。这是后续值得检查的具体位置，尚不是已经证明能安全压缩的方案，也尚未确认该改法有独立新颖性。
更改时必须同步处理见证分区、二进制约束、范数界、矩阵形状和参数生成，且与已有工作比较。

`degree=64` 是此证明表示的环次数，不能据此推断只有 64 位安全，也不能简单对半削减并声称“轻微降低安全等级”。

下一步先分析 pilot 的出示证明时间、验证时间、证明长度和初始化成本，再决定改哪里。

## 6. 来源、许可证和交付内容

- LaZer：https://github.com/lazer-crypto/lazer
- LaZer 论文：https://eprint.iacr.org/2024/1846
- BLNS 框架论文：https://eprint.iacr.org/2023/560
- `PROVENANCE.json`：源码和依赖提交记录。
- `UPSTREAM_SHA256.json`：341 个上游文件的 SHA-256，构建/运行前检查。

保留各上游许可证。压缩包带官方源码、官方依赖压缩包、固定子模块源码和新增运行脚本；不带 `.git` 历史、预编译二进制、机器专用虚拟环境或大规模实验结果。源码体积较小是正常的，并非缺失匿名凭证实现。
