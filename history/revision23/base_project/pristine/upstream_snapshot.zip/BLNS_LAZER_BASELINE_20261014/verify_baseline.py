#!/usr/bin/env python3
from pathlib import Path
import hashlib, json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'UPSTREAM_SHA256.json').read_text())
bad=[]
for name, expected in manifest.items():
    p=root/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=expected:
        bad.append(name)
if bad:
    print('UPSTREAM_INTEGRITY_FAILED:', '\n'.join(bad))
    raise SystemExit(1)
print('UPSTREAM_INTEGRITY_OK:',len(manifest),'files')
