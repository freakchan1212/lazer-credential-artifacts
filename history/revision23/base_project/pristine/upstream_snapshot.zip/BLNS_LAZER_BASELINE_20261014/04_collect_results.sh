#!/usr/bin/env bash
source "$(dirname -- "${BASH_SOURCE[0]}")/common.sh"
choose_python
"$PY" - <<'PY'
from pathlib import Path
from datetime import datetime
import zipfile
root=Path.cwd()
out=root/('normal_path_results_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for name in ['logs','results']:
        for p in sorted((root/name).rglob('*')):
            if p.is_file(): z.write(p,p.relative_to(root))
    for name in ['PROVENANCE.json','UPSTREAM_SHA256.json','README_ZH.md']:
        z.write(root/name,name)
print('Results package:',out)
PY
